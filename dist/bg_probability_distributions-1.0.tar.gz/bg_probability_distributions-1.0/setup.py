from setuptools import setup

setup(name='bg_probability_distributions',
      version='1.0',
      description='Binomial and Gaussian distributions',
      author='Ifeoluwa Oderinde',
      author_email='oderindeife@gmail.com',
      packages=['bg_probability_distributions'],
      zip_safe=False)
